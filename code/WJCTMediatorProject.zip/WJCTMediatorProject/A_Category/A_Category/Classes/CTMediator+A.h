//
//  CTMediator+A.h
//  A_Category_Example
//
//  Created by darkwing90s on 2019/8/3.
//  Copyright © 2019 darkwing90s@163.com. All rights reserved.
//

#import <CTMediator/CTMediator.h>

NS_ASSUME_NONNULL_BEGIN

@interface CTMediator (A)

- (UIViewController *)A_aViewController;

@end

NS_ASSUME_NONNULL_END
