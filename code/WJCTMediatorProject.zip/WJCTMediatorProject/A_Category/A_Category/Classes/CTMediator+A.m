//
//  CTMediator+A.m
//  A_Category_Example
//
//  Created by darkwing90s on 2019/8/3.
//  Copyright © 2019 darkwing90s@163.com. All rights reserved.
//

#import "CTMediator+A.h"

@implementation CTMediator (A)

- (UIViewController *)A_aViewController
{
    /*
     AViewController *viewController = [[AViewController alloc] init];
     */
    return [self performTarget:@"A" action:@"viewController" params:nil shouldCacheTarget:NO];
}

@end
