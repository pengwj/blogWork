//
//  WJViewController.m
//  A_Category
//
//  Created by darkwing90s@163.com on 08/03/2019.
//  Copyright (c) 2019 darkwing90s@163.com. All rights reserved.
//

#import "WJViewController.h"

@interface WJViewController ()

@end

@implementation WJViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
