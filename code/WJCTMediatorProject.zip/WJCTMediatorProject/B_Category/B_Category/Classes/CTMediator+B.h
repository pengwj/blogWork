//
//  CTMediator+B.h
//  B_Category_Example
//
//  Created by darkwing90s on 2019/8/4.
//  Copyright © 2019 darkwing90s@163.com. All rights reserved.
//

#import <CTMediator/CTMediator.h>

NS_ASSUME_NONNULL_BEGIN

@interface CTMediator (B)

- (UIViewController *)B_viewControllerWithContentText:(NSString *)contentText;

@end

NS_ASSUME_NONNULL_END
