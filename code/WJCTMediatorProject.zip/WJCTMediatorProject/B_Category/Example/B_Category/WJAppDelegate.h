//
//  WJAppDelegate.h
//  B_Category
//
//  Created by darkwing90s@163.com on 08/03/2019.
//  Copyright (c) 2019 darkwing90s@163.com. All rights reserved.
//

@import UIKit;

@interface WJAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
