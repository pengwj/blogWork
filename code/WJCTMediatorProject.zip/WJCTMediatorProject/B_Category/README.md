# B_Category

[![CI Status](https://img.shields.io/travis/darkwing90s@163.com/B_Category.svg?style=flat)](https://travis-ci.org/darkwing90s@163.com/B_Category)
[![Version](https://img.shields.io/cocoapods/v/B_Category.svg?style=flat)](https://cocoapods.org/pods/B_Category)
[![License](https://img.shields.io/cocoapods/l/B_Category.svg?style=flat)](https://cocoapods.org/pods/B_Category)
[![Platform](https://img.shields.io/cocoapods/p/B_Category.svg?style=flat)](https://cocoapods.org/pods/B_Category)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

B_Category is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'B_Category'
```

## Author

darkwing90s@163.com, darkwing90s@163.com

## License

B_Category is available under the MIT license. See the LICENSE file for more info.
