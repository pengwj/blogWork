//
//  WjViewController.m
//  A
//
//  Created by darkwing90s@163.com on 08/03/2019.
//  Copyright (c) 2019 darkwing90s@163.com. All rights reserved.
//

#import "WjViewController.h"

@interface WjViewController ()

@end

@implementation WjViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
