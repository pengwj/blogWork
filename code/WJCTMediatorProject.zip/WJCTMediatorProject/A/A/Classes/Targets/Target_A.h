//
//  Target_A.h
//  A_Example
//
//  Created by darkwing90s on 2019/8/3.
//  Copyright © 2019 darkwing90s@163.com. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Target_A : NSObject

- (UIViewController *)Action_viewController:(NSDictionary *)params;

@end

NS_ASSUME_NONNULL_END
