//
//  Target_A.m
//  A_Example
//
//  Created by darkwing90s on 2019/8/3.
//  Copyright © 2019 darkwing90s@163.com. All rights reserved.
//

#import "Target_A.h"
#import "AViewController.h"

@implementation Target_A

- (UIViewController *)Action_viewController:(NSDictionary *)params
{
    AViewController *viewController = [[AViewController alloc] init];
    return viewController;
}

@end
