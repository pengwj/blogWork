# A

[![CI Status](https://img.shields.io/travis/darkwing90s@163.com/A.svg?style=flat)](https://travis-ci.org/darkwing90s@163.com/A)
[![Version](https://img.shields.io/cocoapods/v/A.svg?style=flat)](https://cocoapods.org/pods/A)
[![License](https://img.shields.io/cocoapods/l/A.svg?style=flat)](https://cocoapods.org/pods/A)
[![Platform](https://img.shields.io/cocoapods/p/A.svg?style=flat)](https://cocoapods.org/pods/A)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

A is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'A'
```

## Author

darkwing90s@163.com, darkwing90s@163.com

## License

A is available under the MIT license. See the LICENSE file for more info.
